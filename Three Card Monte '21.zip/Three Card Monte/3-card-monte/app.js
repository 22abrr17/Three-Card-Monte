let userScore = 0;
let computerScore = 0;
const userScore_span = document.getElementById("user-score");
const computerScore_span = document.getElementById("computer-score");
const scoreBoard_div = document.querySelector(".score-board");
const result_p = document.querySelector(".result > p");
const hearts_div = document.getElementById("r");
const diamonds_div = document.getElementById("p");
const aceofspades_div = document.getElementById("s");
const hearts_pic_img = document.getElementById("hearts_pic");
const diamonds_pic_img = document.getElementById("diamonds_pic");
const aceofspades_pic_img = document.getElementById("aceofspades_pic");

// main program
main();


function main() {
	hearts_div.addEventListener('click', function() {
		game("r");
	})
	diamonds_div.addEventListener('click', function() {
		game("p");
	})
	aceofspades_div.addEventListener('click', function() {
		game("s");
	})
	
}

function game(userChoice){
	const computerChoice = getComputerChoice(); //this is where the coin is
	//const result = userChoice + computerChoice;
	//console.log(result);
	console.log(userChoice + computerChoice);
	
	if (userChoice == computerChoice) {
		win(userChoice);
	} else {
		lose(userChoice, computerChoice);
	}	
}

function getComputerChoice(){
	const choices = ["r", "p", "s"];
	let randomNum = Math.floor(Math.random() * choices.length);
	return choices[randomNum];
}

function win(uc) {
	result_p.innerHTML = "You chose the right card, you win!"
	if (uc == "r"){
		console.log("WIN hearts");
		hearts_pic_img.src = "images/coin.png";
	}else if (uc == "p") {
		diamonds_pic_img.src = "images/coin.png";
	}else {
		aceofspades_pic_img.src = "images/coin.png";
	}
}

function lose(uc, cc) {
	result_p.innerHTML = "You chose the wrong card, you lose!"
}
/*
function lose(userChoice, computerChoice){
	computerScore = computerScore + 1;
	computerScore_span.innerHTML = computerScore;
	result_p.innerHTML = convertWord(userChoice) + " loses to " + convertWord(computerChoice) + ". You lose!";
}

function win(userChoice, computerChoice){
	userScore = userScore + 1;
	userScore_span.innerHTML = userScore;
	result_p.innerHTML = convertWord(userChoice) + " beats " + convertWord(computerChoice) + ". You win!";
}

function tie(userChoice){
	result_p.innerHTML = convertWord(userChoice) + " ties " + convertWord(userChoice) + ". You tie!";
}

function convertWord(letter){
	if (letter == "r") {
		return "hearts";
	}
	if (letter == "s") {
		return "aceofspades";
	}
	return "diamonds";
}

*/






